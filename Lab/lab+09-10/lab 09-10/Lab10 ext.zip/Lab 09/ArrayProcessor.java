package main;
/**
 * 
 * @author Mai Văn Mạnh
 * created day: 06/04/2016
 * At: Ton Duc Thang University
 *
 */
public class ArrayProcessor {
	
	private int[] arr;
	
	public ArrayProcessor(int [] arr) {
		this.arr = arr;
	}
	
	public int[] getArray() {
		return this.arr;
	}
	
	/**
	 * Sắp dãy số tăng dần
	 */
	public void sortASC() {
		for (int i = 0; i < arr.length - 1; i++) {
			for (int j = i + 1; j < arr.length; j++) {
				if (arr[i] > arr[j]) {
					int temp = arr[i];
					arr[i] = arr[j];
					arr[j] = temp;
				}
			}
		}
	}
	
	/**
	 * Sắp dãy số giảm dần
	 */
	public void sortDESC() {
		for (int i = 0; i < arr.length - 1; i++) {
			for (int j = i + 1; j < arr.length; j++) {
				if (arr[i] < arr[j]) {
					int temp = arr[i];
					arr[i] = arr[j];
					arr[j] = temp;
				}
			}
		}
	}
	
	/**
	 * Sắp dãy số theo thứ tự như sau:
	 * 	+ Lẽ trước chẵn sau
	 *  + Lẽ thì tăng dần
	 *  + Chẵn thì giảm dần
	 */
	public void newSort() {
		for (int i = 0; i < arr.length - 1; i++) {
			for (int j = i + 1; j < arr.length; j++) {
				if (compare(arr[i],arr[j]) > 0) {
					int temp = arr[i];
					arr[i] = arr[j];
					arr[j] = temp;
				}
			}
		}
	}
	
	/**
	 * Tính tổng tất cả các số nguyên tố có trong danh sách
	 * @return tổng
	 */
	public int PrimeSum() {
		int sum = 0;
		for (int i = 0; i < arr.length; i++) {
			if (isPrimeNumber(i))
				sum += arr[i];
		}
		return sum;
	}
	
	/**
	 * <p>Tính tổng các số lẻ nằm ở vị trí (chỉ số) chẵn, nhưng số đó không phải số nguyên tố.</p>
	 * <p>Chỉ số bắt đầu từ 1</p>
	 * @return
	 */
	public int sumEvenNumberAtOddPosition() {
		int sum = 0;
		for (int i = 0; i < arr.length; i++) {
			if ((i + 1)%2 == 0 && arr[i]%2 != 0) {
				if (isPrimeNumber(i) == false) {
					sum += arr[i];
				}
			}
		}
		
		return sum;
	}
	
	
	/**
	 * Kiểm tra 1 số có phải là số nguyên tố hay không.
	 * Các số nhỏ hơn hoặc bằng 1 thì chắc chắn không phải là số nguyên tố
	 * Các số lớn hơn 1: Phụ thuộc vào kết quả kiểm tra
	 * @param n số cần kiểm tra
	 * @return kết quả
	 */
	public boolean isPrimeNumber(int n) {
		for (int i = 2; i <= Math.sqrt(n); i++) {
			if (n %i == 0)
				return false;
		}
		return true;
	}
	
	/**
	 * Lấy phần tử lại vị trí.
	 * @param index Vị trí cần lấy
	 * @return giá trị phần tử tương ứng
	 * @exception ArrayIndexOutOfBoundsException Khi chỉ số nằm ngoài phạm vi của mảng
	 */
	public int get(int index) {
		return arr[index];
	}

	
	/**
	 * KHÔNG CẦN TEST PHƯƠNG THỨC NÀY
	 */
	private int compare (int a, int b) {
		if (a%2 == 0 && b%2 != 0) {
			return 1;
		}
		else if (a%2 != 0 && b%2 == 0) {
			return -1;
		}else {
			if (a%2 == 0 && b%2 == 0) {
				return a - b;
			}
			return b - a;
		}
	}
	
	
}
