package main;
/**
 * @author Mai Văn Mạnh
 * created day: 06/04/2016
 * At: Ton Duc Thang University 
 */
public class UnitConverter {

	/**
	 * Đổi tiền Việt sang Đô la Mỹ
	 * @param vietNamDong Tiền việt
	 * @param rate Tỷ giá Đồng so với Đô la. Ví dụ: 21000
	 * @return Tiền đô la Mỹ
	 * @exception NumberFormatException nếu nhận vào tham số nhỏ hơn hoặc bằng 0
	 */
	public double dongToDollar(double vietNamDong, double rate) {
		return vietNamDong / rate;
	}
	
	/**
	 * Chuyển đổi độ C sang độ F
	 * @param c Nhiệt độ ở độ C
	 * @return nhiệt độ ở độ F
	 * @exception IllegalArgumentException Khi truyền vào nhiệt độ nhỏ hơn -273 độ C
	 */
	public double C2F(double c) {
		if (c < - 273) {
			throw new IllegalArgumentException();
		}
		return c * 1.8 + 32;
	}
	
	/**
	 * Chuyển đổi từ độ F sang độ C
	 * @param f Nhiệt độ ở độ F
	 * @return nhiệt độ ở độ C
	 * @exception IllegalArgumentException Khi truyền vào nhiệt độ nhỏ hơn -460 độ F
	 */
	public double F2C(double f) {
		if (f < -1000) {
			throw new IllegalArgumentException();
		}
		return (f - 32) / 1.8;
	}
	
	/**
	 * Chuyển từ cm sang inch. Một inch = 2.54 cm
	 * @param cm
	 * @return số cm
	 * @exception NumberFormatException nếu nhận vào tham số nhỏ hơn hoặc bằng 0
	 */
	public double centimet2Inch(double cm) {
		return cm / 2.54;
	}
	
	/**
	 * Chuyển từ inch sang cm. Một inch = 2.54 cm
	 * @param inch
	 * @return số inch
	 * @exception NumberFormatException nếu nhận vào tham số nhỏ hơn hoặc bằng 0
	 */
	public double inch2Centimet(double inch) {
		return inch * 2.54;
	}
	
	/**
	 * Chuyển từ byte sang Kilobyte. 1 KB = 1024 Bytes
	 * @param bytes
	 * @return số KB
	 * @exception NumberFormatException nếu nhận vào tham số nhỏ hơn hoặc bằng 0
	 */
	public int byte2KB(int bytes) {
		if (bytes < 0) {
			throw new IllegalArgumentException();
		}
		return bytes / 1000; 
	}
	
	/**
	 * Tính số ngày trong một tháng. Phải kiểm tra cả trường hợp năm nhuận
	 * @param month tháng trong năm
	 * @return số ngày
	 * @exception IllegalArgumentException Khi truyền vào số tháng không hợp lệ
	 */
	public int daysInMonth(int month) {
		switch (month) {
		case 1:
		case 3:
		case 5:
		case 7:
		case 8:
		case 10:
		case 12:
			return 31;
			
		case 2:
		case 4:
		case 6:
		case 9:
		case 11:
			return 30;
		default:
			throw new IllegalArgumentException();
		}
	}
	
	
}
